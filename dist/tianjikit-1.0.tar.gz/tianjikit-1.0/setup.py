from setuptools import setup 

setup(name='tianjikit', 
      version='1.0', 
      description='tianjikit is an useful toolbox for feature engineering and machine learning in risk management model building.',
      url='https://github.com/lyhue1991/tianjikit', 
      author='Python_Ai_Road', 
      author_email='lyhue1991@163.com', 
      license='MIT', 
      zip_safe=False)
